from textblob import TextBlob

def analyze_sentiment(text):
    blob = TextBlob(text)
    polarity = blob.sentiment.polarity  # -1 (negative) to +1 (positive)

    if polarity > 0.3:
        mood = "positive"
    elif polarity < -0.3:
        mood = "negative"
    else:
        mood = "neutral"

    return mood
