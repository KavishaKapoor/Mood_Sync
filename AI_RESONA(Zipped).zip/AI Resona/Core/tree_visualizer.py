def tree_impact_summary(trees_planted):
    try:
        trees = int(trees_planted)
        co2_offset_kg = trees * 22  # 1 tree ~22kg CO₂ per year
        oxygen_kg = trees * 117  # 1 tree ~117kg O₂/year
        days_off_car = round(co2_offset_kg / 2.3)  # 2.3kg CO₂ = avg/day car emission

        return (
            f"🌳 You've planted {trees} tree(s)!\n"
            f"💨 Estimated CO₂ absorbed yearly: {co2_offset_kg} kg\n"
            f"🌬️ Oxygen produced yearly: {oxygen_kg} kg\n"
            f"🚗 That's like taking a car off the road for {days_off_car} days!"
        )
    except:
        return "❌ Please enter a valid number of trees."
