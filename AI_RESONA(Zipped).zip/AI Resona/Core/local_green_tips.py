def get_local_green_tips(city):
    city = city.lower()
    tips_by_city = {
        "delhi": "🌾 Visit Dilli Haat's organic stalls this weekend!",
        "bangalore": "🌳 Join Lalbagh cleanup drive every Sunday morning.",
        "chennai": "🧺 Check Koyambedu eco-market for local produce.",
        "mumbai": "🌿 Try Versova Beach clean-up meetups on weekends."
    }

    return tips_by_city.get(city, "🌎 Explore your local farmer markets or eco-groups nearby!")
