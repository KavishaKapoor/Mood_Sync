import json
import os
from datetime import datetime

HABITS_FILE = os.path.join("..", "data", "habits.json")

def log_habit(habit, mood="neutral"):
    today = datetime.today().strftime("%Y-%m-%d")

    # Load old memory
    if os.path.exists(HABITS_FILE):
        with open(HABITS_FILE, "r") as file:
            habits = json.load(file)
    else:
        habits = []

    # Add new memory
    habits.append({
        "date": today,
        "habit": habit,
        "mood": mood
    })

    # Save updated memory
    with open(HABITS_FILE, "w") as file:
        json.dump(habits, file, indent=4)

    print(f"✅ Logged: '{habit}' on {today} with mood '{mood}'")
