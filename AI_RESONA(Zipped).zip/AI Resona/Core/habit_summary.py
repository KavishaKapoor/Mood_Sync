import json
import os
from datetime import datetime, timedelta
from collections import Counter

HABITS_FILE = os.path.join("..", "data", "habits.json")

def load_habits():
    if not os.path.exists(HABITS_FILE):
        return []
    with open(HABITS_FILE, "r") as file:
        return json.load(file)

def summarize_habits(days=7):
    habits = load_habits()
    cutoff = datetime.today() - timedelta(days=days)

    filtered = [
        habit for habit in habits
        if datetime.strptime(habit["date"], "%Y-%m-%d") >= cutoff
    ]

    if not filtered:
        return "No green actions logged in the last {} days.".format(days)

    habit_texts = [h["habit"] for h in filtered]
    moods = [h["mood"] for h in filtered]

    top_habits = Counter(habit_texts).most_common(3)
    top_moods = Counter(moods).most_common()

    summary = f"📅 In the last {days} days:\n"
    summary += f"✅ You performed {len(filtered)} green actions.\n"
    summary += f"🔥 Most frequent habit: {top_habits[0][0]} ({top_habits[0][1]} times)\n"
    summary += f"🧠 Mood trend: Mostly {top_moods[0][0]}"

    return summary

