from datetime import datetime

# Log green habit entries into a file
def log_green_habit(habit):
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    entry = f"{now} - {habit}\n"
    with open("data/green_habits.txt", "a") as f:
        f.write(entry)

    return "🌱 Noted! That green habit has been logged."

# View history
def view_green_habits():
    try:
        with open("data/green_habits.txt", "r") as f:
            history = f.readlines()
        return "".join(history[-5:])  # show last 5
    except FileNotFoundError:
        return "📭 No green habits recorded yet!"
