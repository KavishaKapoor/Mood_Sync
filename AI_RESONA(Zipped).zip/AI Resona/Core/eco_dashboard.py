import os

def read_green_habit_count():
    try:
        with open("data/green_habits.txt", "r") as f:
            return len(f.readlines())
    except FileNotFoundError:
        return 0

def read_tree_count():
    try:
        with open("data/tree_count.txt", "r") as f:
            return int(f.read())
    except:
        return 0

def read_water_saved():
    try:
        with open("data/water_saved.txt", "r") as f:
            return int(f.read())
    except:
        return 0

def read_energy_saved():
    try:
        with open("data/energy_saved.txt", "r") as f:
            return int(f.read())
    except:
        return 0

def get_eco_dashboard():
    habits = read_green_habit_count()
    trees = read_tree_count()
    water = read_water_saved()
    energy = read_energy_saved()
    co2 = trees * 22

    return (
        f"📊 Your Eco Dashboard:\n"
        f"🌿 Green Habits Tracked: {habits}\n"
        f"🌳 Trees Planted: {trees}\n"
        f"💧 Water Saved: {water} L\n"
        f"⚡ Energy Saved: {energy} kWh\n"
        f"💨 CO₂ Reduced: {co2} kg\n"
    )
