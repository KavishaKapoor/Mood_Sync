import pyttsx3

engine = pyttsx3.init()

# Optional: You can check all voices available
# voices = engine.getProperty('voices')
# for v in voices:
#     print(v.id)

def speak_response(text, mood="neutral"):
    if mood == "positive":
        engine.setProperty('rate', 180)  # faster
        engine.setProperty('volume', 1.0)
    elif mood == "negative":
        engine.setProperty('rate', 140)  # slower
        engine.setProperty('volume', 0.8)
    else:
        engine.setProperty('rate', 160)
        engine.setProperty('volume', 0.9)

    engine.say(text)
    engine.runAndWait()

