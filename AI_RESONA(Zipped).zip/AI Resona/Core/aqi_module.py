import requests

def get_aqi(city):
    try:
        url = f"https://api.waqi.info/feed/{city}/?token=demo"
        response = requests.get(url).json()

        if response["status"] != "ok":
            return "❌ Could not fetch AQI data. Try another city."

        aqi = response["data"]["aqi"]

        # Category
        if aqi <= 50:
            level = "Good 🍃"
            tip = "Enjoy the fresh air!"
        elif aqi <= 100:
            level = "Moderate 🌤️"
            tip = "Okay for most, but sensitive people should reduce long outdoor exposure."
        elif aqi <= 150:
            level = "Unhealthy for Sensitive Groups 😷"
            tip = "Limit prolonged outdoor exertion."
        elif aqi <= 200:
            level = "Unhealthy 😨"
            tip = "Wear a mask. Limit time outside."
        else:
            level = "Hazardous 🚨"
            tip = "Avoid all outdoor activities."

        return f"🌫️ AQI in {city}: {aqi} → {level}\n💡 Tip: {tip}"

    except Exception as e:
        return f"⚠️ Error: {str(e)}"
