import speech_recognition as sr
import pyttsx3
import time 

recognizer = sr.Recognizer()
engine = pyttsx3.init()

def get_voice_input():
    with sr.Microphone() as source:
        recognizer.adjust_for_ambient_noise(source)
        print("Speak now...")
        audio = recognizer.listen(source)
        print("Audio captured, processing...")
        try:
            text = recognizer.recognize_google(audio)
            print(f"You said: {text}")
            return text
        except sr.UnknownValueError:
            print("Sorry, I couldn't understand that.")
            return None
        except sr.RequestError:
            print("Could not request results.")
            return None

def speak(new_text):
    print(f"[DEBUG] Attempting to say: '{new_text}'")  # Debug print
    engine.say(new_text)
    engine.runAndWait()
    print("[DEBUG] Speech should have been spoken.")   # Debug print
    time.sleep(0.5)

if __name__ == "__main__":
    speak("Hello! I am your voice assistant. How can I assist you today?")
    speak("Test")

    while True:
        command = get_voice_input()
        
        if command is not None:
            command_lower = str(command.lower().strip())
            print(f"Command received: {command}")  # Debug print
            if "hello" in command_lower:
                print("[DEBUG] Matched 'hello'")  # Debug pri
                speak("Hello there!")
            elif "how are you" in command_lower:
                speak("I'm fine, thank you!")
            elif "goodbye" in command_lower:
                speak("Goodbye! Have a great day!")
                break
            else:
                speak("I'm sorry, I don't understand that command.")

        else:
            print("[DEBUG] No command received.")  # Debug print