def estimate_carbon_footprint(diet, appliances):
    diet_emissions = {
        "vegetarian": 2.0,
        "mixed": 3.3,
        "non-vegetarian": 5.0
    }

    appliance_emissions = {
        "ac": 1.5,
        "fridge": 0.5,
        "tv": 0.2,
        "fan": 0.1
    }

    diet_co2 = diet_emissions.get(diet.lower(), 3.0)
    appliance_co2 = sum(appliance_emissions.get(a.lower(), 0) for a in appliances)

    total = diet_co2 + appliance_co2

    return f"🍽️ Diet Emission: {diet_co2:.2f} kg CO₂\n🔌 Appliance Emission: {appliance_co2:.2f} kg CO₂\n🌍 Total: {total:.2f} kg CO₂"
