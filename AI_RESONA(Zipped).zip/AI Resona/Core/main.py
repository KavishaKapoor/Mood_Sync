from sentiment_analysis import analyze_sentiment
from gpt_response import get_gpt_reply
from speech_to_text import get_voice_input
from text_to_speech import speak_response
from habit_tracker import log_habit
from habit_summary import summarize_habits
from aqi_module import get_aqi
from solar_module import estimate_solar_potential
from aqi_module import get_aqi
from solar_module import estimate_solar_potential
from water_module import calculate_water_footprint
from carbon_module import estimate_carbon_footprint
from eco_coach import suggest_green_tips
from green_habit_tracker import log_green_habit, view_green_habits
from local_green_tips import get_local_green_tips
from tree_visualizer import tree_impact_summary
from eco_dashboard import get_eco_dashboard
from garbage_classifier import classify_garbage



def resona_loop():
    print("🧠 RESONA is awake. Say something or type 'exit' to stop.\n")

    while True:
        user_input = get_voice_input()
        if user_input.lower() in ["exit", "quit", "stop"]:
            print("👋 Exiting RESONA. Bye!")
            break
        if user_input.strip() == "":
            continue

        # Analyze sentiment
        mood = analyze_sentiment(user_input)
        print(f"🧠 Detected Mood: {mood}")

        # Check for green celebration keywords
        celebration_keywords = [
            "planted", "cleaned", "cycled", "recycled", "avoided plastic",
            "reduced waste", "saved water", "saved electricity"
        ]

        if any(keyword in user_input.lower() for keyword in celebration_keywords):
            celebration_msg = "🌟 Amazing work, Kavisha! Your green actions are inspiring — the Earth thanks you!"
            print(f"\n{celebration_msg}")
            speak_response(celebration_msg, mood="positive")


        # ✅ Check if user asked for summary
        if "progress" in user_input.lower() or "summary" in user_input.lower():
            summary = summarize_habits()
            print(f"\n📊 RESONA Summary:\n{summary}")
            speak_response(summary)
            continue  # Skip GPT reply

        # Environmental Queries
        if "aqi" in user_input.lower() or "air quality" in user_input.lower():
            speak_response("Please tell me your city name.")
            city = input("🏙️ Enter city: ")
            result = get_aqi(city)
            print(result)
            speak_response(result)
            continue

        if "solar" in user_input.lower() or "sunlight" in user_input.lower():
            speak_response("Please enter your city or region.")
            city = input("🌇 Enter city: ")
            result = estimate_solar_potential(city)
            print(result)
            speak_response(result)
            continue

        if "water footprint" in user_input.lower():
            shower = int(input("🚿 Minutes you showered today: "))
            flushes = int(input("🚽 Toilet flushes today: "))
            laundry = int(input("👕 Laundry loads today: "))
            result = calculate_water_footprint(shower, flushes, laundry)
            print(result)
            speak_response(result)
            continue

        if "carbon footprint" in user_input.lower():
            diet = input("🥦 Your diet (vegetarian / mixed / non-vegetarian): ")
            print("🔌 Appliances used today (separated by commas): ")
            appliances = input().split(",")
            result = estimate_carbon_footprint(diet, appliances)
            print(result)
            speak_response(result)
            continue

        if "classify garbage" in user_input.lower():
            result = classify_garbage()
            print(result)
            speak_response(result)


        if "log habit" in user_input.lower():
            habit = input("🌿 What green habit did you do today? ")
            result = log_green_habit(habit)
            print(result)
            speak_response(result)
            continue

        if "view habits" in user_input.lower():
            result = view_green_habits()
            print(result)
            speak_response(result)
            continue

        if "eco tip" in user_input.lower() or "green advice" in user_input.lower():
            habits_today = input("📋 Describe your green actions today (comma separated): ").lower().split(",")
            result = suggest_green_tips(habits_today)
            print(result)
            speak_response(result)
            continue

        if "local green" in user_input.lower() or "eco events" in user_input.lower():
            city = input("🏙️ Enter your city name: ")
            result = get_local_green_tips(city)
            print(result)
            speak_response(result)
            continue

        if "planted tree" in user_input.lower():
            trees = input("🌱 How many trees did you plant? ")
            try:
                with open("data/tree_count.txt", "r") as f:
                    current = int(f.read())
            except:
                current = 0

            updated = current + int(trees)
            with open("data/tree_count.txt", "w") as f:
                f.write(str(updated))

            summary = tree_impact_summary(trees)
            print(summary)
            speak_response(summary)
            continue

        if "eco dashboard" in user_input.lower():
            result = get_eco_dashboard()
            print(result)
            speak_response(result)
            continue



        # ✅ Log habit
        log_habit(user_input, mood)

        # Generate GPT/Gemini response with emotion context
        prompt = f"The user is feeling {mood}. Respond accordingly to their message: {user_input}"
        response = get_gpt_reply(prompt)

        print(f"🤖 RESONA: {response}")
        speak_response(response, mood)

if __name__ == "__main__":
    resona_loop()
