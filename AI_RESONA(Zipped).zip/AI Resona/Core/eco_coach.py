def suggest_green_tips(current_habits):
    tips = []

    if "bike" not in current_habits and "walk" not in current_habits:
        tips.append("🚲 Try biking or walking short distances instead of using a car.")

    if "plastic" in current_habits:
        tips.append("♻️ Avoid single-use plastics. Carry a cloth bag or metal bottle.")

    if "shower" in current_habits and "long" in current_habits:
        tips.append("💧 Shorten your showers to save 20+ liters daily.")

    if not tips:
        tips.append("🌍 You're doing great! Keep it up. Plant a tree this week maybe?")

    return "\n".join(tips)
