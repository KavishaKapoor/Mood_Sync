# config.py

openai_api_key = "AIzaSyDPepfbdiZeA80CV7rq5ou3aSfeHGZYtcY"