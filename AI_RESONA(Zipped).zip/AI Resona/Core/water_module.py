def calculate_water_footprint(shower_time, toilet_flushes, laundry_loads):
    shower_per_min = 9  # liters
    flush_per_use = 6
    laundry_per_load = 50

    total = (shower_time * shower_per_min) + \
            (toilet_flushes * flush_per_use) + \
            (laundry_loads * laundry_per_load)

    tips = "💧 Tip: Shorten your showers, use dual-flush toilets, and wash full laundry loads."

    return f"🚿 Water Used Today: {total} liters.\n{tips}"
