def estimate_solar_potential(city):
    # Dummy estimates based on average sunlight hours
    sunlight_hours = {
        "delhi": 5.5,
        "mumbai": 6.2,
        "chennai": 6.0,
        "bangalore": 5.8,
        "default": 5.5
    }

    city_key = city.lower()
    hours = sunlight_hours.get(city_key, sunlight_hours["default"])

    daily_output_kw = hours * 1  # 1kW solar panel
    co2_saved = daily_output_kw * 0.92  # kg of CO2 saved per day

    return (
        f"☀️ Average Sunlight in {city}: {hours} hrs/day\n"
        f"🔋 Daily Energy Output (1kW panel): {daily_output_kw:.2f} kWh\n"
        f"🌱 Daily CO₂ Saved: {co2_saved:.2f} kg\n"
        f"💡 Solar panels are viable in your region!"
    )
