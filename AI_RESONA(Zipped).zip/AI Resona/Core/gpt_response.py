import google.generativeai as genai
from config import openai_api_key

# Configure your Gemini API Key here
genai.configure(api_key=openai_api_key)  # <-- Replace with your real key

# Initialize the Gemini model
model = genai.GenerativeModel("models/gemini-1.5-flash-latest")

# Function to get reply
def get_gpt_reply(prompt):
    try:
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        return f"Resona is having trouble: {str(e)}"

