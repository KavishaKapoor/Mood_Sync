import cv2
from roboflow import Roboflow
import os

# Replace with your real API key
rf = Roboflow(api_key="xZZOTjmsDBBR7NBiGiFy")
project = rf.workspace("jp-waste-classification").project("waste-detection")
model = project.version(1).model


def classify_garbage():
    # Capture image from webcam
    cam = cv2.VideoCapture(0)
    ret, frame = cam.read()
    img_path = "garbage_sample.jpg"
    
    if ret:
        cv2.imwrite(img_path, frame)
        cam.release()
        cv2.destroyAllWindows()
        
        # Predict using Roboflow
        prediction = model.predict(img_path, confidence=40, overlap=30).json()
        
        if prediction['predictions']:
            pred = prediction['predictions'][0]
            label = pred['class']
            confidence = round(pred['confidence'] * 100, 2)
            result = f"This looks like {label} with {confidence} percent confidence."
        else:
            result = "Sorry, I couldn't recognize the waste item."

        return result
        

        # Optional: clean up
        os.remove(img_path)

    else:
        return "Sorry, I couldn't access the camera."
